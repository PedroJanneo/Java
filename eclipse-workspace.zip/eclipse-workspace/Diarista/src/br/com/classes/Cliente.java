package br.com.classes;

public class Cliente {
	
	//atribuiçao
	
	public String pix;
	
	//metodo
	
	public void deposito(int depositocliente) {
		
		
	}

}
