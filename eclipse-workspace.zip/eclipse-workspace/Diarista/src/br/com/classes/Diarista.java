package br.com.classes;

public class Diarista {

	
	//atributo
	
	public  String nome;
	public String telefone;
	public String endereco;
	
	//metodo/açao
	
	public void job(String nomeCliente) {
		System.out.println("Diarista realizando o atendimento para "+nomeCliente);
	}
	
}
