/**
 * 
 */
/**
 * 
 */
module Diarista {
}